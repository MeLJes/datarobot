<?php
/**
 * Default template
 *
 * @package datarobot
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>DataRobot - Our open positions</title>

  <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" type="images/x-icon" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Titillium+Web:400,600,700&display=swap">
  <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css">

  <style>
    :root {
      --default: #23232D;
      --primary: #2D8FE2;
      --secondary: #53718F;
      --extra: #E1E8F0;

      --white: #ffffff;
      --black: #000000;
      --gray: #808080;
      --light-gray: #D0D8E2;
      --dark-gray: #656565;

      --success: #b1d845;
      --warning: #ffeaa7;
      --error: #e41c1c;
    }
  </style>
</head>

<body class="loading">
<div class="loader">
  <div class="logo">
    <img src="<?php echo get_template_directory_uri(); ?>/images/logo.svg"
         alt="<?php bloginfo( 'name' ); ?> | <?php _e('DataRobot - Icon', 'datarobot'); ?>" />
  </div><!-- .logo -->

  <div class="spinner">
    <img src="<?php echo get_template_directory_uri(); ?>/icons/loaders/loader.svg"
         alt="<?php bloginfo( 'name' ); ?> | <?php _e('DataRobot - Icon', 'datarobot'); ?>">
  </div><!-- .spinner -->
</div><!-- .loader -->

<div class="main-content">
  <div class="header">
    <h1>Our open positions</h1>

    <div id="dropdown" class="dropdown">
      <button type="button" id="active-item" data-department-id="all">
        All departments
      </button><!-- .active-item -->

      <ul id="dropdown-items">
        <?php renderDropdown(); ?>
      </ul><!-- .dropdown-items -->
    </div><!-- .dropdown -->
  </div><!-- .header -->

  <div id="positions" class="loaded">
    <?php renderPositions(); ?>
  </div><!-- .positions -->

  <div id="pagination">
  </div><!-- .pagination -->
</div><!-- .main-content -->

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>
</body>
</html>
