<?php

$originalData = NULL;

function getData($depId = 'all') {
  global $originalData;

  if( $originalData ) {
    $request = $originalData;
  } else {
    $request = wp_remote_get( 'https://api.jsonbin.io/b/5dd7cefb040d843991f7183c' );
    $originalData = $request;
  }

  if( is_wp_error( $request ) ) {
    return false;
  }
  $body = wp_remote_retrieve_body( $request );
  $data = json_decode( $body );

  if( $depId === 'all' ) {
    return $data;
  } else {
    $getFilteredData = [];

    foreach ($data->jobs as $job) {
      if( $job->departments[0] === (int)$depId ) {
        $getFilteredData[] = $job;
      }
    }

    $data->jobs = $getFilteredData;

    return $data;
  }
}

function getPositionName($positionId) {
  $getData = getData();

  foreach ($getData->departments as $department) {
    if( $department->id === $positionId ) {
      return $department->name;
    }
  }
}

function renderDropdown() {
  $getData = getData();

  if( ! empty( $getData ) ) { ?>
    <li class="dropdown-item" data-department-id="all">All departments </li>

    <?php foreach( $getData->departments as $department ) { ?>
      <li class="dropdown-item" data-department-id="<?php echo $department->id ?>">
        <?php echo $department->name ?>
      </li>
    <?php unset( $getData ); }
  }
}

function renderPositions() {
  $depId = stripslashes( $_POST['depId'] );

  if( $depId ) {
    $getData = getData($depId);
  } else {
    $getData = getData();
  }

  if( ! empty( $getData ) ) {
    $job_index = 10;

    foreach( $getData->jobs as $job ) {
      $positionName = getPositionName($job->departments[0]); ?>
      <div class="item"
           data-item-number="<?php echo $job_index ?>"
           data-item-department="<?php echo $job->departments[0] ?>">
        <h2 data-position="<?php echo $job->title ?>">
          <a href="<?php echo $job->absolute_url ?>">
            <?php echo $job->title ?>
          </a>
        </h2>

        <div class="info">
          <div class="city"
               data-item-city="<?php echo $job->location->name ?>">
            <div class="media-holder">
              <img src="<?php echo get_template_directory_uri(); ?>/icons/city.svg" alt="DataRobot" />
            </div><!-- .media-holder -->

            <?php echo $job->location->name ?>
          </div><!-- .city -->

          <div class="department"
               data-item-department="<?php echo $job->departments[0] ?>">
            <div class="media-holder">
              <img src="<?php echo get_template_directory_uri(); ?>/icons/department.svg" alt="DataRobot" />
            </div><!-- .media-holder -->

            <?php echo $positionName ?>
          </div><!-- .place -->
        </div><!-- .info -->

        <a href="<?php echo $job->absolute_url ?>"
           class="more">
          <?php _e('Learn more', 'datarobot'); ?>

          <img src="<?php echo get_template_directory_uri(); ?>/icons/more.svg" alt="DataRobot" />
        </a><!-- .more -->
      </div><!-- .item -->
      <?php
        $job_index++;
        /*unset( $positionName );*/
    }

    /*unset( $getData );*/
  }

  if( $depId ) {
    die;
  }
}
add_action('wp_ajax_load_data', 'renderPositions'); // wp_ajax_{action}
add_action('wp_ajax_nopriv_load_data', 'renderPositions'); // wp_ajax_nopriv_{action}
