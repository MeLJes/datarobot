const dropdown = document.getElementById('dropdown-items');
const dropdownActive = document.getElementById('active-item');
const positions = document.getElementById('positions');

async function getNewData(depId) {
  const url = '/wp-admin/admin-ajax.php';
  const params = new URLSearchParams({
    action: 'load_data',
    depId
  });

  try {
    const response = await fetch(url, {
      method: 'POST',
      body: params,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
    const html = await response.text();

    if( html ) {
      setTimeout(function () {
        positions.innerHTML = html;
      }, 250);

      setTimeout(function () {
        positions.classList.add('loaded');
      }, 325);
    } else {
      positions.innerHTML = '<h2>Sorry, no data available</h2>'
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

(function () {
  // --- Dropdown element click
  Array.from(document.getElementsByClassName('dropdown-item')).forEach(item => {
    item.addEventListener('click', () => {
      positions.classList.remove('loaded');

      getNewData(item.dataset.departmentId);

      dropdownActive.innerHTML = item.innerHTML;
      document.getElementById('dropdown-items').classList.remove('active');
    });
  });

  // --- Main
  document.addEventListener('DOMContentLoaded', () => {
    // --- Dropdown
    document.getElementById('active-item').addEventListener('click', () => {
      // --- Open dropdown
      document.getElementById('dropdown-items').classList.toggle('active');
    });
  });

  // --- Events
  window.addEventListener('load', () => {
    document.body.classList.remove('loading');
    document.body.classList.add('loaded');
  });
})();